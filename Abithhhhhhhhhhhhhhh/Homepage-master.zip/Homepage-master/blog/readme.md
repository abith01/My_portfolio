Welcome.

Note that a few graphic have no pages, since they are studied in the caveat section:

- boxplot
- spider chart
- pie chart
